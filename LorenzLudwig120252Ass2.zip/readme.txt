Exercise 2 - Algorithms and Data Sructures

Python is required to run the code.
Made by Ludwig Lorenz (120252)