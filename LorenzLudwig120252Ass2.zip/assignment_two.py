# random is a library that supports pseudo random choosing numbers
import random

"""
Ludwig Lorenz 120252
HeapSort Implementation - 24.5.2019 AlgoDat Exercise 2
Sources:
https://www.geeksforgeeks.org/heap-sort/
https://en.wikipedia.org/wiki/Heapsort
"""


# swaps two elements in an array
def swap(array, index1, index2):
    element = array[index1]
    array[index1] = array[index2]
    array[index2] = element


# brings an array in heap order
def heapify(array, length, index):
    leftchild = 2 * index + 1
    rightchild = 2 * index + 2
    largest = index
    if leftchild < length:
        if rightchild < length:
            if array[rightchild] > array[largest]:
                largest = rightchild
        if array[leftchild] > array[largest]:
            largest = leftchild
    if largest != index:
        # switches the index node with the largest children node
        swap(array, largest, index)
        # and then calls recursively the heapify function with
        # the position, where the largest children was before
        heapify(array, length, largest)


# applies heapify to all nodes except most leaf nodes
# nodes getting selected from the bottom
def initialheap(array):
    for i in range(int(len(array)/2),-1, -1):
        heapify(array, len(array), i)


# main sorting function
def heapsort(array):
    # the unsorted array forms into an heap by calling initialheap()
    initialheap(array)
    to_swap = len(array)-1
    # brings the maximal element to the back
    # and decreases the range of the heap
    while to_swap > 0:
        swap(array, 0, to_swap)
        heapify(array, to_swap, 0)
        to_swap = to_swap - 1

def main():
    # I decided to sort an array with an uneven length to check whether
    # the addressing of children nodes is implemented well
    # I also tested borderline cases like negative, neutral and float numbers
    test = [15, 3, 4, 72, -13, 6845, 0, 40, -1503, 98, 4, -58, 30]
    print(test)
    initialheap(test)
    heapsort(test)
    print(test)
    print()

    # In addition I added a test with pseudo random numbers
    supertest = [int(random.random()*1200-200)/100 for i in range(60)]
    print(supertest)
    heapsort(supertest)
    print(supertest)


if __name__ == "__main__":
    # execute only if run as a script
    main()